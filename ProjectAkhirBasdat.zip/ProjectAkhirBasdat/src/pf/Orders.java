
package pf;

import java.sql.*;
import java.awt.Dimension;
import java.awt.Toolkit;
import static java.lang.Integer.parseInt;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Orders extends javax.swing.JFrame {

    
    public Orders() {
        initComponents();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
        showTableDataOL();
    }
    
    private void showTableDataOL() {
        try {
            ResultSet x = FPage.dc.TableData("detail_pesanan");
            while (x.next()){
                Object no_pesanan = x.getInt(1);
                Object id_kurir = x.getInt(2);
                Object no_hp = x.getString(3);
                Object tanggal = x.getString(4);
                Object mp = x.getString(5);
                Object alamat = x.getString(6);
                Object status = x.getInt(7);
                Object th = x.getInt(8);
                int A;
                String st;
                A= (parseInt(status.toString()));
                if (A==1){
                    st = "Dalam Proses";
                } else if(A==2){
                    st = "Telah Diantarkan";
                } else {
                    st = "Dibatalkan";
                }
                
                Object[] data = {no_pesanan, id_kurir, no_hp, tanggal, mp, alamat, st, th};

                DefaultTableModel tblModelOrders = (DefaultTableModel) jTableOL.getModel();
                tblModelOrders.addRow(data);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void search(Object y) {
        try {
            ResultSet x = FPage.dc.TableData("detail_pesanan");
            DefaultTableModel tbl = (DefaultTableModel) jTableOL.getModel();
            while (x.next()) {
                Object no_pesanan = x.getInt(1);
                Object id_kurir = x.getInt(2);
                Object no_hp = x.getString(3);
                Object tanggal = x.getString(4);
                Object mp = x.getString(5);
                Object alamat = x.getString(6);
                Object status = x.getInt(7);
                Object th = x.getInt(8);
              int A;
                String st;
                A= (parseInt(status.toString()));
                if (A==1){
                    st = "Dalam Proses";
                } else if(A==2){
                    st = "Telah Diantarkan";
                } else {
                    st = "Dibatalkan";
                }
                
                Object[] data = {no_pesanan, id_kurir, no_hp, tanggal, mp, alamat, st, th};
                if (no_hp.toString().equalsIgnoreCase(y.toString()) || no_pesanan.toString().equalsIgnoreCase(y.toString())
                        || id_kurir.toString().equalsIgnoreCase(y.toString()) || tanggal.toString().equalsIgnoreCase(y.toString())
                        || mp.toString().equalsIgnoreCase(y.toString()) || alamat.toString().equalsIgnoreCase(y.toString()) || st.equalsIgnoreCase(y.toString())) {
                    tbl.addRow(data);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void clearTableOC() {
        DefaultTableModel oc = (DefaultTableModel) jTableOC.getModel();
        int rowsCount = oc.getRowCount();
        for (int i = rowsCount - 1; i >= 0; i--) {
            oc.removeRow(i);
        }
    }
    
    private void searchLike(String y) {
        try {
            DefaultTableModel tbl = (DefaultTableModel) jTableOL.getModel();
            PreparedStatement statement = db_connection.conn.prepareStatement(
                    "select * from detail_pesanan where cast(tanggal_pesanan as date) like ?");
            String q = "%" + y + "%";
            statement.setString(1, q);
            ResultSet x = statement.executeQuery();

            while (x.next()) {
                Object no_pesanan = x.getInt(1);
                Object id_kurir = x.getInt(2);
                Object no_hp = x.getString(3);
                Object tanggal = x.getString(4);
                Object mp = x.getString(5);
                Object alamat = x.getString(6);
                Object status = x.getInt(7);
                Object th = x.getInt(8);
                int A;
                String st;
                A= (parseInt(status.toString()));
                if (A==1){
                    st = "Dalam Proses";
                } else if(A==2){
                    st = "Telah Diantarkan";
                } else {
                    st = "Dibatalkan";
                }
                
                Object[] data = {no_pesanan, id_kurir, no_hp, tanggal, mp, alamat, st, th};
                tbl.addRow(data);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void clearTable() {
        DefaultTableModel tbl = (DefaultTableModel) jTableOL.getModel();
        int rowsCount = tbl.getRowCount();
        for (int i = rowsCount - 1; i >= 0; i--) {
            tbl.removeRow(i);
        }
    }
    
    private void showTableDataCC(int no_keranjang){
        try {
            String q = "select * from list_pesanan_harga where no_pesanan=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, no_keranjang);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                Object id_menu = rs.getInt(2);
                Object kuantitas = rs.getInt(3);
                Object harga = rs.getInt(4);
                Object[] data = {id_menu, kuantitas, harga};
                DefaultTableModel tbl = (DefaultTableModel) jTableOC.getModel();
                tbl.addRow(data);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Cart.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator1 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabelPF = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabelDrivers = new javax.swing.JLabel();
        jLabelCustomers = new javax.swing.JLabel();
        jLabelOrders = new javax.swing.JLabel();
        jLabelSellers = new javax.swing.JLabel();
        jLabelImgDriver = new javax.swing.JLabel();
        jLabelImgOrders = new javax.swing.JLabel();
        jLabelImgCust1 = new javax.swing.JLabel();
        jLabelImgSeller = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableOL = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableOC = new javax.swing.JTable();
        jPanel8 = new javax.swing.JPanel();
        jLabelDriversR = new javax.swing.JLabel();
        jTFSearch = new javax.swing.JTextField();
        jButtonSearch = new javax.swing.JButton();
        jButtonX = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(new java.awt.Dimension(930, 551));

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));

        jPanel1.setBackground(new java.awt.Color(255, 51, 255));

        jLabelPF.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        jLabelPF.setForeground(new java.awt.Color(255, 255, 255));
        jLabelPF.setText("PATRICK FOODIES");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelPF, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelPF)
                .addGap(30, 30, 30))
        );

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));

        jLabelDrivers.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelDrivers.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDrivers.setText("Drivers");
        jLabelDrivers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelDriversMouseClicked(evt);
            }
        });

        jLabelCustomers.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelCustomers.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCustomers.setText("Customers");
        jLabelCustomers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelCustomersMouseClicked(evt);
            }
        });

        jLabelOrders.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelOrders.setForeground(new java.awt.Color(255, 255, 255));
        jLabelOrders.setText("Orders");

        jLabelSellers.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelSellers.setForeground(new java.awt.Color(255, 255, 255));
        jLabelSellers.setText("Sellers");
        jLabelSellers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelSellersMouseClicked(evt);
            }
        });

        jLabelImgDriver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-scooter-60.png"))); // NOI18N
        jLabelImgDriver.setText("jLabel1");

        jLabelImgOrders.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-order-64.png"))); // NOI18N

        jLabelImgCust1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-customer-64.png"))); // NOI18N
        jLabelImgCust1.setText("jLabel1");

        jLabelImgSeller.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-store-64.png"))); // NOI18N

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setText("Kembali ke Beranda");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabelImgCust1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelImgDriver, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelImgOrders, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelImgSeller, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelDrivers)
                            .addComponent(jLabelOrders)
                            .addComponent(jLabelSellers))
                        .addContainerGap(40, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabelCustomers)
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelImgDriver)
                    .addComponent(jLabelDrivers))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelImgCust1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabelCustomers)
                        .addGap(10, 10, 10)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabelImgOrders))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jLabelOrders)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jLabelImgSeller)
                        .addGap(35, 35, 35))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelSellers)
                        .addGap(51, 51, 51)))
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 204, 255));

        jTableOL.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No. Pesanan", "ID Kurir", "No. HP", "Tanggal Pesanan", "Metode Pembayaran", "Alamat Pesanan", "Status Pesanan", "Harga"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableOL.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTableOL.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTableOL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableOLMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableOL);

        jPanel7.setBackground(new java.awt.Color(51, 51, 51));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("ORDER CONTENTS");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addContainerGap(26, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTableOC.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Makanan", "Kuantitas", "Harga"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableOC.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTableOC.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane2.setViewportView(jTableOC);

        jPanel8.setBackground(new java.awt.Color(51, 51, 51));

        jLabelDriversR.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelDriversR.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDriversR.setText("ORDERS LIST");

        jTFSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFSearchActionPerformed(evt);
            }
        });

        jButtonSearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-search-24.png"))); // NOI18N
        jButtonSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSearchActionPerformed(evt);
            }
        });

        jButtonX.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonX.setText("X");
        jButtonX.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonXActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelDriversR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTFSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 494, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButtonX, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonSearch, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButtonX, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonSearch, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelDriversR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTFSearch))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 32, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(158, 158, 158))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 478, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabelDriversMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelDriversMouseClicked
        // TODO add your handling code here:
        new Drivers().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelDriversMouseClicked

    private void jLabelCustomersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelCustomersMouseClicked
        // TODO add your handling code here:
        new Customers().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelCustomersMouseClicked

    private void jLabelSellersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelSellersMouseClicked
        new Sellers().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelSellersMouseClicked

    private void jTableOLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableOLMouseClicked

        jTableOL.setRowSelectionAllowed(true);
        DefaultTableModel cl = (DefaultTableModel) jTableOL.getModel();
        String no_pesanan = cl.getValueAt(jTableOL.getSelectedRow(), 0).toString();
        clearTableOC();
        showTableDataCC(parseInt(no_pesanan));
    }//GEN-LAST:event_jTableOLMouseClicked

    private void jTFSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFSearchActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jTFSearchActionPerformed

    private void jButtonSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSearchActionPerformed

        if(!jTFSearch.getText().equals("")){
            DefaultTableModel tbl = (DefaultTableModel)jTableOL.getModel();
            clearTable();
            Object x = jTFSearch.getText();
            search(x);
            if(tbl.getRowCount()==0){
                searchLike(x.toString());
            }
        }
    }//GEN-LAST:event_jButtonSearchActionPerformed

    private void jButtonXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonXActionPerformed
        
        jTFSearch.setText("");
        clearTable();
        clearTableOC();
        showTableDataOL();
    }//GEN-LAST:event_jButtonXActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        new firstPage().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Orders.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Orders().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButtonSearch;
    private javax.swing.JButton jButtonX;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabelCustomers;
    private javax.swing.JLabel jLabelDrivers;
    private javax.swing.JLabel jLabelDriversR;
    private javax.swing.JLabel jLabelImgCust1;
    private javax.swing.JLabel jLabelImgDriver;
    private javax.swing.JLabel jLabelImgOrders;
    private javax.swing.JLabel jLabelImgSeller;
    private javax.swing.JLabel jLabelOrders;
    private javax.swing.JLabel jLabelPF;
    private javax.swing.JLabel jLabelSellers;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField jTFSearch;
    private javax.swing.JTable jTableOC;
    private javax.swing.JTable jTableOL;
    // End of variables declaration//GEN-END:variables
}
