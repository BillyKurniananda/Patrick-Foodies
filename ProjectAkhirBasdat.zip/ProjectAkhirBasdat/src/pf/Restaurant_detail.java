/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pf;

import java.sql.*;
import java.awt.Dimension;
import java.awt.Toolkit;
import static java.lang.Integer.parseInt;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Restaurant_detail extends javax.swing.JFrame {

    static int idr = -1;
    
    public Restaurant_detail() {
        initComponents();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
        jLRD.setText(showRName(Home.forDetailR));
        showMenu(Home.forDetailR);
        idr = Home.forDetailR;
        Home.forDetailR = -1;
        jBAdd.setVisible(false);
        jBMinus.setVisible(false);
        jBSave.setVisible(false);
        jTFQ.setVisible(false);
        jBX.setVisible(false);
        jBBK.setVisible(false);
        jTFHarga.setVisible(false);
        if(isCartExist(idr, Login.user) != -1){
            jBBK.setVisible(true);
        }
    }
    
    private String showRName(int id_penjual){
        String name="";
        try {
            String q = "select nama_toko from penjual where id_penjual=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1,id_penjual);
            ResultSet rs = st.executeQuery();
            while (rs.next())
            name = rs.getString("nama_toko");
            
        } catch (SQLException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
        return name;
    }
    
    private void showMenu(int id_penjual){
        try {
            DefaultTableModel tbl = (DefaultTableModel) jTableRM.getModel();
            String q = "select nama_makanan, harga from menu where id_penjual=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q); 
            st.setInt(1, id_penjual);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                String nama_makanan = rs.getString(1);
                int harga = rs.getInt(2);
                Object[] data = {nama_makanan, harga};
                tbl.addRow(data);
            }
                    
        } 
        catch (SQLException ex) {
            Logger.getLogger(Restaurant_detail.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private int showQuantity(int id_penjual, String nama_makanan, int harga, String no_hp){
        int quan = 0;
        try {
            String q = "select kuantitas from buatTabelRM where id_penjual=? and harga=? and nama_makanan=? and no_hp=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, id_penjual);
            st.setInt(2, harga);
            st.setString(3, nama_makanan);
            st.setString(4, no_hp);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                quan = rs.getInt("kuantitas");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Restaurant_detail.class.getName()).log(Level.SEVERE, null, ex);
        }
        return quan;
    }
    
    private void deleteTable(){
        DefaultTableModel tbl = (DefaultTableModel) jTableRM.getModel();
        int rowsCount = tbl.getRowCount();
        for (int i = rowsCount - 1; i >= 0; i--) {
            tbl.removeRow(i);
        }
    }
    
    private void clear(){
        deleteTable();
        showMenu(idr);
        jBAdd.setVisible(false);
        jBMinus.setVisible(false);
        jBSave.setVisible(false);
        jTFQ.setText("");
        jTFQ.setVisible(false);
        jBX.setVisible(false);
        jTFHarga.setVisible(false);
        
    }
    
    public static int isCartExist(int id_penjual,String no_hp){
        int res = -1;
        try {
            String q = "select no_keranjang from buatTabelRM where id_penjual=? and no_hp=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, id_penjual);
            st.setString(2, no_hp);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                res = rs.getInt("no_keranjang");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Restaurant_detail.class.getName()).log(Level.SEVERE, null, ex);
        }
        return res;
    }
    
    private int getIdMenu(int id_penjual, String nama_makanan, int harga){
        int id = -1;
        try {
            String q = "select id_makanan from menu where id_penjual=? and harga=? and nama_makanan=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, id_penjual);
            st.setInt(2, harga);
            st.setString(3, nama_makanan);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                id = rs.getInt("id_makanan");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Restaurant_detail.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id;
    }
    
    private boolean isMenuExistInCart(int no_keranjang, int id_menu){
        boolean res = false;
        int count = 0;
        try {
            String q = "select id_makanan from menambahkan where no_keranjang=? and id_makanan=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, no_keranjang);
            st.setInt(2, id_menu);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                count++;
            }
            if(count > 0) res = true;
        } catch (SQLException ex) {
            Logger.getLogger(Restaurant_detail.class.getName()).log(Level.SEVERE, null, ex);
        }
        return res;
    }
    
    private void addMenuToCart(int no_keranjang, int id_makanan, int kuantitas){
        try {
            String q = "insert into menambahkan values(?,?,?)";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1,no_keranjang);
            st.setInt(2, id_makanan);
            st.setInt(3, kuantitas);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Restaurant_detail.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void updateMenuInCart(int no_keranjang, int id_makanan, int kuantitas){
        try {
            String q = "update menambahkan set kuantitas=? where no_keranjang=? and id_makanan=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, kuantitas);
            st.setInt(2, no_keranjang);
            st.setInt(3, id_makanan);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Restaurant_detail.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void createCart(String no_hp){
        try {
            String q = "insert into keranjang(no_hp) values(?)";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setString(1, no_hp);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Restaurant_detail.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void deleteMenuInCart(int no_keranjang, int id_makanan){
        try {
            String q = "delete from menambahkan where no_keranjang=? and id_makanan=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, no_keranjang);
            st.setInt(2, id_makanan);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Restaurant_detail.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 
    
    private void deleteCart(int no_keranjang){
        try {
            String q = "delete from keranjang where no_keranjang=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, no_keranjang);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void deleteUpdate() {
        try {
            ResultSet delCart = FPage.dc.TableData("cekMenuDiKeranjang");
            while(delCart.next()){
                int k = delCart.getInt(1);
                deleteCart(k);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private int getNewCart() {
        int id = -1;
        try {
            ResultSet x = FPage.dc.TableData("cekMenuDiKeranjang");
            while(x.next()){
                id = x.getInt("no_keranjang");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableRM = new javax.swing.JTable();
        jBSave = new javax.swing.JButton();
        jBBK = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLogOut = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabelDriversR = new javax.swing.JLabel();
        jLabelDriversR3 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabelPF7 = new javax.swing.JLabel();
        jBKembali = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLRD = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jBMinus = new javax.swing.JButton();
        jTFQ = new javax.swing.JTextField();
        jBAdd = new javax.swing.JButton();
        jBX = new javax.swing.JButton();
        jTFHarga = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 204, 255));

        jTableRM.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nama Makanan", "Harga"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableRM.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTableRM.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTableRM.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableRMMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableRM);

        jBSave.setBackground(new java.awt.Color(153, 255, 0));
        jBSave.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBSave.setForeground(new java.awt.Color(255, 255, 255));
        jBSave.setText("Simpan");
        jBSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBSaveActionPerformed(evt);
            }
        });

        jBBK.setBackground(new java.awt.Color(255, 102, 102));
        jBBK.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBBK.setForeground(new java.awt.Color(255, 255, 255));
        jBBK.setText("Buka Pesanan");
        jBBK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBBKActionPerformed(evt);
            }
        });

        jPanel8.setBackground(new java.awt.Color(255, 153, 255));
        jPanel8.setForeground(new java.awt.Color(51, 51, 51));

        jLogOut.setBackground(new java.awt.Color(255, 0, 153));
        jLogOut.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLogOut.setForeground(new java.awt.Color(255, 255, 255));
        jLogOut.setText("Log Out");
        jLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jLogOutActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/download-removebg-preview (1).png"))); // NOI18N
        jLabel1.setText("jLabel1");

        jLabelDriversR.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelDriversR.setForeground(new java.awt.Color(51, 51, 51));
        jLabelDriversR.setText("RIWAYAT");
        jLabelDriversR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelDriversRMouseClicked(evt);
            }
        });

        jLabelDriversR3.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelDriversR3.setForeground(new java.awt.Color(51, 51, 51));
        jLabelDriversR3.setText("PENGATURAN");
        jLabelDriversR3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelDriversR3MouseClicked(evt);
            }
        });

        jPanel9.setBackground(new java.awt.Color(255, 51, 255));

        jLabelPF7.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        jLabelPF7.setForeground(new java.awt.Color(255, 255, 255));
        jLabelPF7.setText("PATRICK FOODIES");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelPF7, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelPF7)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jBKembali.setBackground(new java.awt.Color(102, 204, 255));
        jBKembali.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBKembali.setForeground(new java.awt.Color(255, 255, 255));
        jBKembali.setText("Kembali");
        jBKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBKembaliActionPerformed(evt);
            }
        });

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/12345__1_-removebg-preview.png"))); // NOI18N
        jLabel6.setText("jLabel2");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelDriversR)
                            .addComponent(jLabelDriversR3)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jBKembali)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelDriversR3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addComponent(jLabelDriversR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(73, 73, 73))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLogOut, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                    .addComponent(jBKembali, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(44, 44, 44))
        );

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));

        jLRD.setBackground(new java.awt.Color(255, 255, 255));
        jLRD.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLRD.setForeground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("SELLERS");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(jLRD, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLRD, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(16, 16, 16))
        );

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));
        jPanel3.setForeground(new java.awt.Color(51, 51, 51));

        jBMinus.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jBMinus.setForeground(new java.awt.Color(102, 102, 102));
        jBMinus.setText("-");
        jBMinus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBMinusActionPerformed(evt);
            }
        });

        jTFQ.setForeground(new java.awt.Color(0, 0, 0));
        jTFQ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFQActionPerformed(evt);
            }
        });

        jBAdd.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jBAdd.setForeground(new java.awt.Color(102, 102, 102));
        jBAdd.setText("+");
        jBAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBAddActionPerformed(evt);
            }
        });

        jBX.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jBX.setForeground(new java.awt.Color(102, 102, 102));
        jBX.setText("X");
        jBX.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBXActionPerformed(evt);
            }
        });

        jTFHarga.setForeground(new java.awt.Color(0, 0, 0));
        jTFHarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFHargaActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Total");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jBMinus, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTFQ, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBX, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jTFHarga, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTFQ)
                    .addComponent(jBMinus, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
                    .addComponent(jTFHarga, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jBAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jBX, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jBSave, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jBBK))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(0, 26, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBSave, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBBK, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(68, 68, 68))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTableRMMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableRMMouseClicked
        jBAdd.setVisible(true);
        jBMinus.setVisible(true);
        jBSave.setVisible(true);
        jTFQ.setVisible(true);
        jBX.setVisible(true);
        jTFHarga.setVisible(true);
        String nama_makanan = jTableRM.getValueAt(jTableRM.getSelectedRow(), 0).toString();
        int harga = parseInt(jTableRM.getValueAt(jTableRM.getSelectedRow(), 1).toString());
        Object kuantitas =showQuantity(idr, nama_makanan, harga, Login.user);
        jTFQ.setText(kuantitas.toString());
        Object th = harga * parseInt(kuantitas.toString());
        jTFHarga.setText(th.toString());
    }//GEN-LAST:event_jTableRMMouseClicked

    private void jBXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBXActionPerformed
        // TODO add your handling code here:
        clear();
    }//GEN-LAST:event_jBXActionPerformed

    private void jBKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBKembaliActionPerformed
        // TODO add your handling code here:
        new Home().setVisible(true);
        dispose();
    }//GEN-LAST:event_jBKembaliActionPerformed

    private void jBSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBSaveActionPerformed
        String nama_makanan = jTableRM.getValueAt(jTableRM.getSelectedRow(), 0).toString();
        String harga = jTableRM.getValueAt(jTableRM.getSelectedRow(), 1).toString();
        String kuantitas = jTFQ.getText();
        int id_menu = getIdMenu(idr, nama_makanan, parseInt(harga));
        if(isCartExist(idr, Login.user) != -1){
            if(isMenuExistInCart(isCartExist(idr, Login.user),id_menu) == false && parseInt(kuantitas)!=0){
                addMenuToCart(isCartExist(idr, Login.user), id_menu, parseInt(kuantitas));
                JOptionPane.showMessageDialog(this, "Menu Telah Ditambahkan.");
            }
            else{
                if(parseInt(kuantitas)!=0){
                    updateMenuInCart(isCartExist(idr, Login.user), id_menu, parseInt(kuantitas));
                }
                else{
                    deleteMenuInCart(isCartExist(idr, Login.user), id_menu);
                    deleteUpdate();
                }
                JOptionPane.showMessageDialog(this, "Menu Telah Diupdate.");
            }
            clear();
        }
        else{
            createCart(Login.user);
            jBBK.setVisible(true);
            if(isMenuExistInCart(getNewCart(),id_menu) == false && parseInt(kuantitas)!=0){
                addMenuToCart(getNewCart(), id_menu, parseInt(kuantitas));
                JOptionPane.showMessageDialog(this, "Menu Telah Ditambahkan.");
            }
            clear();
        }
           if(isCartExist(idr, Login.user) == -1){
            jBBK.setVisible(false);
        }
    }//GEN-LAST:event_jBSaveActionPerformed

    private void jBAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBAddActionPerformed
        // TODO add your handling code here:
        Integer init = parseInt(jTFQ.getText());
        init++;
        jTFQ.setText(init.toString());
        int harga = parseInt(jTableRM.getValueAt(jTableRM.getSelectedRow(), 1).toString());
        int kuantitas = parseInt(jTFQ.getText());
        jTFHarga.setText(String.valueOf(harga*kuantitas));
    }//GEN-LAST:event_jBAddActionPerformed

    private void jBMinusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBMinusActionPerformed
        // TODO add your handling code here:
        if(parseInt(jTFQ.getText()) != 0){
            Integer init = parseInt(jTFQ.getText());
            init--;
            jTFQ.setText(init.toString());
            int harga = parseInt(jTableRM.getValueAt(jTableRM.getSelectedRow(), 1).toString());
            int kuantitas = parseInt(jTFQ.getText());
            jTFHarga.setText(String.valueOf(harga*kuantitas));
        }
    }//GEN-LAST:event_jBMinusActionPerformed

    private void jBBKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBBKActionPerformed
        // TODO add your handling code here:
        new DetailedCart().setVisible(true);
        dispose();
    }//GEN-LAST:event_jBBKActionPerformed

    private void jLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jLogOutActionPerformed
        // TODO add your handling code here:
        Login.user = "";
        new Login().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLogOutActionPerformed

    private void jLabelDriversRMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelDriversRMouseClicked
        new History().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelDriversRMouseClicked

    private void jLabelDriversR3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelDriversR3MouseClicked
        new Setting().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelDriversR3MouseClicked

    private void jTFQActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFQActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFQActionPerformed

    private void jTFHargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFHargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFHargaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Restaurant_detail.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Restaurant_detail.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Restaurant_detail.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Restaurant_detail.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Restaurant_detail().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBAdd;
    private javax.swing.JButton jBBK;
    private javax.swing.JButton jBKembali;
    private javax.swing.JButton jBMinus;
    private javax.swing.JButton jBSave;
    private javax.swing.JButton jBX;
    private javax.swing.JLabel jLRD;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabelDriversR;
    private javax.swing.JLabel jLabelDriversR3;
    private javax.swing.JLabel jLabelPF7;
    private javax.swing.JButton jLogOut;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTFHarga;
    private javax.swing.JTextField jTFQ;
    private javax.swing.JTable jTableRM;
    // End of variables declaration//GEN-END:variables
}
