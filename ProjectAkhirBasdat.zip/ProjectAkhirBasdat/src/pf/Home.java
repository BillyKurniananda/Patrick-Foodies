
package pf;

import java.sql.*;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Home extends javax.swing.JFrame {
    String userHome = "";
    static int forDetailR = -1;
    static boolean justOrdered = false;
    static boolean justCanceled = false;
    
    public Home() {
        initComponents();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
        if(justOrdered==true){
            JOptionPane.showMessageDialog(this, "Pesanan anda telah sampai.");
            justOrdered = false;
        }
        if(justCanceled==true){
            JOptionPane.showMessageDialog(this, "Pesanan anda telah dibatalkan.");
            justCanceled = false;
        }
        showTableData();
        jLabelTitle.setText(showName(Login.user));
         jLOVO.setText(String.valueOf(getSaldoOVO(Login.user))); 
        
    }
    
    
      private int getSaldoOVO(String no_hp){
        int saldo = 0;
        try {
            String q = "select saldo_ovo from pembeli where no_hp=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setString(1, no_hp);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                saldo = rs.getInt("saldo_ovo");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
        return saldo;
    }
      
    private void showTableData() {
        try {
            ResultSet x = FPage.dc.TableData("penjual");
            while (x.next()){
                Object nama_toko = x.getString(1);
                Object jalan = x.getString(5);
                Object blok_jalan = x.getString(6);
                Object kota = x.getString(7);
                Object[] data = {nama_toko,jalan, blok_jalan, kota};

                DefaultTableModel tblModelSellers = (DefaultTableModel) jTableSearch.getModel();
                tblModelSellers.addRow(data);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private String showName(String no_hp){
        String name="";
        try {
            String q = "select nama from pembeli where no_hp=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setString(1,no_hp);
            ResultSet rs = st.executeQuery();
            while (rs.next())
            name = rs.getString("nama");
            
        } catch (SQLException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
        return name;
    }
    
    private void searchRestaurant(String y){
        try {
            ResultSet rs = FPage.dc.TableData("penjual");
            DefaultTableModel tbl = (DefaultTableModel)jTableSearch.getModel();
            while(rs.next()){
                String namaT = rs.getString(1);
                String jalan = rs.getString(5);
                String blok_jalan = rs.getString(6);
                String kota = rs.getString(7);
                String[] data = {namaT, jalan, blok_jalan, kota};
                if(namaT.equalsIgnoreCase(y)){
                    tbl.addRow(data);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void searchLikeRestaurant(String y){
        try {
            DefaultTableModel tblModelSellers = (DefaultTableModel) jTableSearch.getModel();
            PreparedStatement statement = db_connection.conn.prepareStatement(
                    "select * from penjual where nama_toko like ?");
            String q = "%" + y + "%";
            statement.setString(1, q);
            ResultSet rs = statement.executeQuery();

            while (rs.next()) {
                String namaT = rs.getString(1);
                String jalan = rs.getString(5);
                String blok_jalan = rs.getString(6);
                String kota = rs.getString(7);
                String[] data = {namaT, jalan, blok_jalan, kota};
                tblModelSellers.addRow(data);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    private void clearTable() {
        DefaultTableModel tbl = (DefaultTableModel) jTableSearch.getModel();
        int rowsCount = tbl.getRowCount();
        for (int i = rowsCount - 1; i >= 0; i--) {
            tbl.removeRow(i);
        }
    }
    
    private void searchFood(String nama_makanan){
        try {
            DefaultTableModel tbl = (DefaultTableModel)jTableSearch.getModel();
            String x = "%" + nama_makanan + "%";
            String q = "select distinct y.*\n" + "from menu x\n" + "join penjual y on x.id_penjual=y.id_penjual\n" + "where nama_makanan like ?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setString(1, x);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                String namaT = rs.getString(1);
                String jalan = rs.getString(5);
                String blok_jalan = rs.getString(6);
                String kota = rs.getString(7);
                String[] data = {namaT, jalan, blok_jalan, kota};
                tbl.addRow(data);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private int getIdRestaurant(String namaT, String jalan, String blok_jalan, String kota){
        int res = -1;
        try {
            String q = "select id_penjual from penjual where nama_toko=? and jalan=? and blok_jalan=? and kota=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setString(1, namaT);
            st.setString(2, jalan);
            st.setString(3, blok_jalan);
            st.setString(4, kota);
            ResultSet rs = st.executeQuery();
            while (rs.next())
            res = rs.getInt("id_penjual");
                    
        }
        catch(SQLException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
        return res;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelTitle = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableSearch = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        jTFSearch = new javax.swing.JTextField();
        jBSearch = new javax.swing.JButton();
        jBX = new javax.swing.JButton();
        jLabelDriversR2 = new javax.swing.JLabel();
        jLabelDriversR1 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLogOut = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabelPF3 = new javax.swing.JLabel();
        jLabelDriversR = new javax.swing.JLabel();
        jLabelDriversR3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLOVO = new javax.swing.JLabel();
        jBTopUp = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 204, 255));

        jLabelTitle.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelTitle.setForeground(new java.awt.Color(0, 0, 0));

        jTableSearch.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nama Toko", "Jalan", "Blok Jalan", "Kota"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableSearch.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTableSearch.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTableSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableSearchMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTableSearch);

        jPanel6.setBackground(new java.awt.Color(51, 51, 51));
        jPanel6.setForeground(new java.awt.Color(51, 51, 51));

        jBSearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-search-24.png"))); // NOI18N
        jBSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBSearchActionPerformed(evt);
            }
        });

        jBX.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jBX.setText("x");
        jBX.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBXActionPerformed(evt);
            }
        });

        jLabelDriversR2.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelDriversR2.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDriversR2.setText("SEARCH");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabelDriversR2)
                .addGap(18, 18, 18)
                .addComponent(jTFSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBX, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabelDriversR2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jBSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jBX, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTFSearch))
                        .addGap(1, 1, 1)))
                .addContainerGap())
        );

        jLabelDriversR1.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelDriversR1.setForeground(new java.awt.Color(0, 0, 0));
        jLabelDriversR1.setText("Hai Selamat Datang ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabelDriversR1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabelTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 573, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabelDriversR1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jLabelTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(255, 153, 255));
        jPanel5.setForeground(new java.awt.Color(51, 51, 51));

        jLogOut.setBackground(new java.awt.Color(255, 0, 153));
        jLogOut.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLogOut.setForeground(new java.awt.Color(255, 255, 255));
        jLogOut.setText("Log Out");
        jLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jLogOutActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/download-removebg-preview (1).png"))); // NOI18N
        jLabel1.setText("jLabel1");

        jPanel4.setBackground(new java.awt.Color(255, 51, 255));

        jLabelPF3.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        jLabelPF3.setForeground(new java.awt.Color(255, 255, 255));
        jLabelPF3.setText("PATRICK FOODIES");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelPF3, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelPF3)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jLabelDriversR.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelDriversR.setForeground(new java.awt.Color(51, 51, 51));
        jLabelDriversR.setText("RIWAYAT");
        jLabelDriversR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelDriversRMouseClicked(evt);
            }
        });

        jLabelDriversR3.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelDriversR3.setForeground(new java.awt.Color(51, 51, 51));
        jLabelDriversR3.setText("PENGATURAN");
        jLabelDriversR3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelDriversR3MouseClicked(evt);
            }
        });

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/12345__1_-removebg-preview.png"))); // NOI18N
        jLabel6.setText("jLabel2");

        jPanel2.setBackground(new java.awt.Color(255, 102, 204));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Saldo OVO :");

        jLOVO.setBackground(new java.awt.Color(255, 255, 255));
        jLOVO.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLOVO.setForeground(new java.awt.Color(255, 255, 255));

        jBTopUp.setBackground(new java.awt.Color(153, 102, 255));
        jBTopUp.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBTopUp.setForeground(new java.awt.Color(255, 255, 255));
        jBTopUp.setText("Top Up");
        jBTopUp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBTopUpActionPerformed(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/OVO-Logo-Vector-removebg-preview (1).png"))); // NOI18N
        jLabel3.setText("jLabel3");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jBTopUp)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLOVO, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLOVO, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBTopUp, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(9, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(jLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelDriversR)
                                    .addComponent(jLabelDriversR3))))))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelDriversR3))
                .addGap(28, 28, 28)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelDriversR))
                .addGap(28, 28, 28)
                .addComponent(jLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBSearchActionPerformed
        DefaultTableModel tbl = (DefaultTableModel) jTableSearch.getModel();
        clearTable();
        if(!jTFSearch.getText().equals("")){
            String w = jTFSearch.getText();
            searchRestaurant(w);
            if(tbl.getRowCount() == 0){
                searchLikeRestaurant(w);
                if(tbl.getRowCount() == 0){
                    searchFood(w);
                }
            }
        }
    }//GEN-LAST:event_jBSearchActionPerformed

    private void jBXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBXActionPerformed
        jTFSearch.setText("");
        clearTable();
        showTableData();
    }//GEN-LAST:event_jBXActionPerformed

    private void jTableSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableSearchMouseClicked
        // TODO add your handling code here:
        String namaT = jTableSearch.getValueAt(jTableSearch.getSelectedRow(), 0).toString();
        String jalan = jTableSearch.getValueAt(jTableSearch.getSelectedRow(), 1).toString();
        String blok_jalan = jTableSearch.getValueAt(jTableSearch.getSelectedRow(), 2).toString();
        String kota = jTableSearch.getValueAt(jTableSearch.getSelectedRow(), 3).toString();
        forDetailR = getIdRestaurant(namaT, jalan, blok_jalan, kota);
        new Restaurant_detail().setVisible(true);
        dispose();
    }//GEN-LAST:event_jTableSearchMouseClicked

    private void jLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jLogOutActionPerformed
        // TODO add your handling code here:
        Login.user = "";
        new Login().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLogOutActionPerformed

    private void jLabelDriversRMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelDriversRMouseClicked
          new History().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelDriversRMouseClicked

    private void jLabelDriversR3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelDriversR3MouseClicked
        new Setting().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelDriversR3MouseClicked

    private void jBTopUpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBTopUpActionPerformed
        // TODO add your handling code here:
        new topUp().setVisible(true);
        dispose();
    }//GEN-LAST:event_jBTopUpActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBSearch;
    private javax.swing.JButton jBTopUp;
    private javax.swing.JButton jBX;
    private javax.swing.JLabel jLOVO;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabelDriversR;
    private javax.swing.JLabel jLabelDriversR1;
    private javax.swing.JLabel jLabelDriversR2;
    private javax.swing.JLabel jLabelDriversR3;
    private javax.swing.JLabel jLabelPF3;
    private javax.swing.JLabel jLabelTitle;
    private javax.swing.JButton jLogOut;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTFSearch;
    private javax.swing.JTable jTableSearch;
    // End of variables declaration//GEN-END:variables
}
