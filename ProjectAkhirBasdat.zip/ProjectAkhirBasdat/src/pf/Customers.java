package pf;

import java.sql.*;
import java.awt.Dimension;
import java.awt.Toolkit;
import static java.lang.Integer.parseInt;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Customers extends javax.swing.JFrame {
    
    static String forCart = "";
    String status = "";
    String initNumber = "";
    
    public Customers() {
        initComponents();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
        showTableData();
        jButtonSave.setEnabled(false);
        jButtonCancel.setEnabled(false);
        jButtonCart.setEnabled(false);
    }
    
    private void showTableData() {
        try {
            ResultSet x = FPage.dc.TableData("pembeli");
            while (x.next()){
                Object nama = x.getString(1);
                Object no_hp = x.getString(2);
                Object email = x.getString(3);
                Object saldo_ovo = x.getInt(4);
                Object[] data = {nama, no_hp, email, saldo_ovo};

                DefaultTableModel tblModelCustomers = (DefaultTableModel) jTableCustomers.getModel();
                tblModelCustomers.addRow(data);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void deleteOrders(String no_hp) {
        try {
            String queryDelete = "delete from pesanan where no_hp=?";
            PreparedStatement st = db_connection.conn.prepareStatement(queryDelete);
            st.setString(1, no_hp);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void deleteListMenu(int no_pesanan) {
        try {
            String queryDelete = "delete from list_menu where no_pesanan=?";
            PreparedStatement st = db_connection.conn.prepareStatement(queryDelete);
            st.setInt(1, no_pesanan);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void deleteRecord(String no_hp) {
        try {
            String queryDelete = "delete from pembeli where no_hp=?";
            PreparedStatement st = db_connection.conn.prepareStatement(queryDelete);
            st.setString(1, no_hp);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private int[] increase_arr(int[] x){
        int[] newArr = new int[x.length + 1];
        System.arraycopy(x, 0, newArr, 0, x.length); //Copying the elements to the new array
        return newArr;
    }
    
    private int[] searchListCart(String no_hp){
        int[] res = new int[1];
        try {
            String q = "select no_keranjang from keranjang where no_hp=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setString(1, no_hp);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                int nk = rs.getInt("no_keranjang");
                res[res.length-1]=nk;
                res = increase_arr(res);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
        return res;
    }
    
    private int[] searchOrders(String no_hp){
        int[] res = new int[1];
        try {
            String q = "select no_pesanan from pesanan where no_hp=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setString(1, no_hp);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                int np = rs.getInt("no_pesanan");
                res[res.length-1]=np;
                res = increase_arr(res);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
        return res;
    }
    
    private void deleteMenambahkan(int no_keranjang){
        try {
            String q = "delete from menambahkan where no_keranjang=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, no_keranjang);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void deleteKeranjang(String no_hp){
        try {
            String q = "delete from keranjang where no_hp=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setString(1, no_hp);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private boolean phoneNumberExist(String no_hp){
        boolean res = false;
        int count = 0;
        try {
            String q = "select * from pembeli where no_hp=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setString(1, no_hp);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                count++;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
        if(count>0){
            res = true;
        }
        return res;
    }
    
    private void saveAdd(String nama, String no_hp, String email) {
        try {
            String queryAdd = "insert into pembeli(nama, no_hp, email) values(?,?,?)";
            PreparedStatement st = db_connection.conn.prepareStatement(queryAdd);
            st.setString(1, nama);
            st.setString(2, no_hp);
            st.setString(3, email);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void saveEdit(String nama, String no_hp, String no_hpinit, String email) {
        try {
            String queryEdit = "update pembeli set nama=?, no_hp=?, email=? where no_hp=?";
            PreparedStatement st = db_connection.conn.prepareStatement(queryEdit);
            st.setString(1, nama);
            st.setString(2, no_hp);
            st.setString(3, email);
            st.setString(4, no_hpinit);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void clearTable() {
        DefaultTableModel tblModelCustomers = (DefaultTableModel) jTableCustomers.getModel();
        int rowsCount = tblModelCustomers.getRowCount();
        for (int i = rowsCount - 1; i >= 0; i--) {
            tblModelCustomers.removeRow(i);
        }
    }
    
    private void search(Object y) {
        try {
            ResultSet x = FPage.dc.TableData("pembeli");
            DefaultTableModel tblModelDrivers = (DefaultTableModel) jTableCustomers.getModel();
            while (x.next()) {
                Object nama = x.getString(1);
                Object no_hp = x.getString(2);
                Object email = x.getString(3);
                Object[] data = {nama, no_hp, email};
                if(email != null){
                    if (no_hp.toString().equalsIgnoreCase(y.toString()) || nama.toString().equalsIgnoreCase(y.toString())
                            || email.toString().equalsIgnoreCase(y.toString())) {
                        tblModelDrivers.addRow(data);
                    }
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void searchLike(String x) {
        try {
            DefaultTableModel tblModelCustomers = (DefaultTableModel) jTableCustomers.getModel();
            PreparedStatement statement = db_connection.conn.prepareStatement(
                    "select * from pembeli where nama like ?");
            String q = "%" + x + "%";
            statement.setString(1, q);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Object nama = resultSet.getString(1);
                Object no_hp = resultSet.getString(2);
                Object email = resultSet.getString(3);
                Object[] data = {nama, no_hp, email};
                tblModelCustomers.addRow(data);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Customers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void cancel() {
        status = "";
        jButtonAdd.setEnabled(true);
        jButtonDelete.setEnabled(true);
        jButtonEdit.setEnabled(true);
        jButtonSave.setEnabled(false);
        jButtonCancel.setEnabled(false);
        jButtonCart.setEnabled(false);
        jTFNoHp.setText("");
        jTFNama.setText("");
        jTFEmail.setText("");
        initNumber = "";
        clearTable();
        showTableData();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabelPF1 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabelDrivers = new javax.swing.JLabel();
        jLabelCustomers = new javax.swing.JLabel();
        jLabelOrders = new javax.swing.JLabel();
        jLabelSellers = new javax.swing.JLabel();
        jLabelImgDriver = new javax.swing.JLabel();
        jLabelImgOrders = new javax.swing.JLabel();
        jLabelImgCust1 = new javax.swing.JLabel();
        jLabelImgSeller = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableCustomers = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabelDriversR = new javax.swing.JLabel();
        jTFSearch = new javax.swing.JTextField();
        jButtonSearch = new javax.swing.JButton();
        jButtonX = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jButtonAdd = new javax.swing.JButton();
        jButtonEdit = new javax.swing.JButton();
        jButtonDelete = new javax.swing.JButton();
        jButtonSave = new javax.swing.JButton();
        jButtonCancel = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTFNoHp = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTFNama = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTFEmail = new javax.swing.JTextField();
        jButtonCart = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(new java.awt.Dimension(800, 590));

        jPanel4.setBackground(new java.awt.Color(51, 51, 51));

        jPanel2.setBackground(new java.awt.Color(255, 51, 255));

        jLabelPF1.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        jLabelPF1.setForeground(new java.awt.Color(255, 255, 255));
        jLabelPF1.setText("PATRICK FOODIES");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelPF1, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelPF1)
                .addGap(30, 30, 30))
        );

        jPanel5.setBackground(new java.awt.Color(51, 51, 51));

        jLabelDrivers.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelDrivers.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDrivers.setText("Drivers");
        jLabelDrivers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelDriversMouseClicked(evt);
            }
        });

        jLabelCustomers.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelCustomers.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCustomers.setText("Customers");

        jLabelOrders.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelOrders.setForeground(new java.awt.Color(255, 255, 255));
        jLabelOrders.setText("Orders");
        jLabelOrders.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelOrdersMouseClicked(evt);
            }
        });

        jLabelSellers.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelSellers.setForeground(new java.awt.Color(255, 255, 255));
        jLabelSellers.setText("Sellers");
        jLabelSellers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelSellersMouseClicked(evt);
            }
        });

        jLabelImgDriver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-scooter-60.png"))); // NOI18N
        jLabelImgDriver.setText("jLabel1");

        jLabelImgOrders.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-order-64.png"))); // NOI18N

        jLabelImgCust1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-customer-64.png"))); // NOI18N
        jLabelImgCust1.setText("jLabel1");

        jLabelImgSeller.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-store-64.png"))); // NOI18N

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setText("Kembali ke Beranda");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabelImgCust1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelCustomers))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabelImgSeller, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelSellers))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(jLabelImgDriver, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabelImgOrders, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelDrivers)
                            .addComponent(jLabelOrders))))
                .addContainerGap(26, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelImgDriver)
                    .addComponent(jLabelDrivers))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelImgCust1)
                    .addComponent(jLabelCustomers))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabelImgOrders))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jLabelOrders)))
                .addGap(24, 24, 24)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelImgSeller)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabelSellers)))
                .addGap(37, 37, 37)
                .addComponent(jButton1)
                .addContainerGap(62, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(255, 204, 255));

        jTableCustomers.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTableCustomers.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nama", "No_HP", "Email", "Saldo OVO"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableCustomers.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTableCustomers.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTableCustomers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableCustomersMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableCustomers);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        jLabelDriversR.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelDriversR.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDriversR.setText("CUSTOMERS");

        jTFSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFSearchActionPerformed(evt);
            }
        });

        jButtonSearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-search-24.png"))); // NOI18N
        jButtonSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSearchActionPerformed(evt);
            }
        });

        jButtonX.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonX.setText("X");
        jButtonX.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonXActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelDriversR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTFSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButtonX, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButtonSearch, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelDriversR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTFSearch)
                    .addComponent(jButtonX, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));

        jButtonAdd.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonAdd.setText("Add");
        jButtonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddActionPerformed(evt);
            }
        });

        jButtonEdit.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonEdit.setText("Edit");
        jButtonEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditActionPerformed(evt);
            }
        });

        jButtonDelete.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonDelete.setText("Delete");
        jButtonDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDeleteActionPerformed(evt);
            }
        });

        jButtonSave.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonSave.setText("Save");
        jButtonSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSaveActionPerformed(evt);
            }
        });

        jButtonCancel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonCancel.setText("Cancel");
        jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButtonAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButtonEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButtonDelete)
                .addGap(18, 18, 18)
                .addComponent(jButtonSave)
                .addGap(18, 18, 18)
                .addComponent(jButtonCancel)
                .addGap(17, 17, 17))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE, false)
                    .addComponent(jButtonEdit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonDelete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonSave, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonCancel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel7.setBackground(new java.awt.Color(51, 51, 51));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText(" No.Hp ");

        jTFNoHp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFNoHpActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nama");

        jTFNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFNamaActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Email");

        jTFEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFEmailActionPerformed(evt);
            }
        });

        jButtonCart.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonCart.setText("Open Cart");
        jButtonCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCartActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTFNoHp, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTFNama, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jTFEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonCart))
                .addGap(77, 77, 77))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFNoHp)
                    .addComponent(jTFEmail))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTFNama))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButtonCart)))
                .addGap(30, 30, 30))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(42, 42, 42))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabelDriversMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelDriversMouseClicked
        // TODO add your handling code here:
        new Drivers().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelDriversMouseClicked

    private void jTableCustomersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableCustomersMouseClicked
        // TODO add your handling code here:
        jTableCustomers.setRowSelectionAllowed(true);
        DefaultTableModel tbl = (DefaultTableModel) jTableCustomers.getModel();
        String nama = tbl.getValueAt(jTableCustomers.getSelectedRow(), 0).toString();
        String no_hp = tbl.getValueAt(jTableCustomers.getSelectedRow(), 1).toString();
        String email = tbl.getValueAt(jTableCustomers.getSelectedRow(), 2).toString();
       
        jTFNama.setText(nama);
        jTFNoHp.setText(no_hp);
        jTFEmail.setText(email);    
        jButtonCart.setEnabled(true);
        forCart = no_hp;
        initNumber = jTableCustomers.getValueAt(jTableCustomers.getSelectedRow(), 1).toString();
    }//GEN-LAST:event_jTableCustomersMouseClicked

    private void jTFSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFSearchActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jTFSearchActionPerformed

    private void jButtonSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSearchActionPerformed

        if(!jTFSearch.getText().equals("")){
            DefaultTableModel tblModelDrivers = (DefaultTableModel)jTableCustomers.getModel();
            clearTable();
            Object x = jTFSearch.getText();
            search(x);
            if(tblModelDrivers.getRowCount()==0){
                searchLike(x.toString());
            }
        }
    }//GEN-LAST:event_jButtonSearchActionPerformed

    private void jButtonXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonXActionPerformed
        // TODO add your handling code here:
        jTFSearch.setText("");
        jTFNoHp.setText("");
        jTFNama.setText("");
        jTFEmail.setText("");
        jButtonCart.setEnabled(false);
        clearTable();
        showTableData();
    }//GEN-LAST:event_jButtonXActionPerformed

    private void jButtonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddActionPerformed
        // TODO add your handling code here:
        jButtonAdd.setEnabled(false);
        jButtonDelete.setEnabled(false);
        jButtonEdit.setEnabled(false);
        jButtonSave.setEnabled(true);
        jButtonCancel.setEnabled(true);
        jButtonCart.setEnabled(false);
        jTFNoHp.setText("");
        jTFNama.setText("");
        jTFEmail.setText("");
        status = "add";
    }//GEN-LAST:event_jButtonAddActionPerformed

    private void jButtonEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditActionPerformed

         if (jTableCustomers.getSelectionModel().isSelectionEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a record!");
        } else {
            jButtonAdd.setEnabled(false);
            jButtonDelete.setEnabled(false);
            jButtonEdit.setEnabled(false);
            jButtonSave.setEnabled(true);
            jButtonCancel.setEnabled(true);
            jButtonCart.setEnabled(false);
            status = "edit";
        }
    }//GEN-LAST:event_jButtonEditActionPerformed

    private void jButtonDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDeleteActionPerformed
     if(jTableCustomers.getSelectionModel().isSelectionEmpty()){
            JOptionPane.showMessageDialog(this,"Select a record!");
        }
        else{
            int response = JOptionPane.showConfirmDialog(this, "Do you want to delete this record?", "Confirm",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if(response==JOptionPane.YES_OPTION){
                DefaultTableModel tbl = (DefaultTableModel)jTableCustomers.getModel();
                String no_hp = tbl.getValueAt(jTableCustomers.getSelectedRow(), 1).toString();
                int[] lc = searchListCart(no_hp);
                for(int i = 0; i < lc.length; i++){
                    deleteMenambahkan(lc[i]);
                }
                deleteKeranjang(no_hp);
                int[] lm = searchOrders(no_hp);
                for(int i = 0; i < lm.length; i++){
                    deleteListMenu(lm[i]);
                }
                deleteOrders(no_hp);
                deleteRecord(no_hp);
                cancel();
            }
        }
    }//GEN-LAST:event_jButtonDeleteActionPerformed

    private void jButtonSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSaveActionPerformed

        String no_hp = jTFNoHp.getText();
        String nama = jTFNama.getText();
        String email = jTFEmail.getText();

        if(!no_hp.equals("") && !nama.equals("")){
            
            if(no_hp.matches("^[0-9]*$") && no_hp.length() >= 11){
                if(status.equals("add")){
                    if(phoneNumberExist(no_hp)==false){
                        saveAdd(nama, no_hp, email); 
                    }
                    else{
                        JOptionPane.showMessageDialog(this, "Phone number registered already.");
                        cancel();
                    }
                }
                else if(status.equals("edit")){
                    saveEdit(nama, no_hp, initNumber,email); 
                }
            }else{
                JOptionPane.showMessageDialog(this, "Insert phone number correctly(only use numbers).");
                cancel();
            }
            
            cancel();
        }
        else{
            JOptionPane.showMessageDialog(this, "Input all the data!");
            cancel();
        }
    }//GEN-LAST:event_jButtonSaveActionPerformed

    private void jButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelActionPerformed
        // TODO add your handling code here:
        cancel();
    }//GEN-LAST:event_jButtonCancelActionPerformed

    private void jTFNoHpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFNoHpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFNoHpActionPerformed

    private void jTFNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFNamaActionPerformed

    private void jTFEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFEmailActionPerformed

    private void jButtonCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCartActionPerformed
        // TODO add your handling code here:
        new Cart().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButtonCartActionPerformed

    private void jLabelSellersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelSellersMouseClicked
        // TODO add your handling code here:
        new Sellers().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelSellersMouseClicked

    private void jLabelOrdersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelOrdersMouseClicked
        // TODO add your handling code here:
        new Orders().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelOrdersMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        new firstPage().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Customers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Customers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Customers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Customers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Customers().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButtonAdd;
    private javax.swing.JButton jButtonCancel;
    private javax.swing.JButton jButtonCart;
    private javax.swing.JButton jButtonDelete;
    private javax.swing.JButton jButtonEdit;
    private javax.swing.JButton jButtonSave;
    private javax.swing.JButton jButtonSearch;
    private javax.swing.JButton jButtonX;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabelCustomers;
    private javax.swing.JLabel jLabelDrivers;
    private javax.swing.JLabel jLabelDriversR;
    private javax.swing.JLabel jLabelImgCust1;
    private javax.swing.JLabel jLabelImgDriver;
    private javax.swing.JLabel jLabelImgOrders;
    private javax.swing.JLabel jLabelImgSeller;
    private javax.swing.JLabel jLabelOrders;
    private javax.swing.JLabel jLabelPF1;
    private javax.swing.JLabel jLabelSellers;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTFEmail;
    private javax.swing.JTextField jTFNama;
    private javax.swing.JTextField jTFNoHp;
    private javax.swing.JTextField jTFSearch;
    private javax.swing.JTable jTableCustomers;
    // End of variables declaration//GEN-END:variables
}
