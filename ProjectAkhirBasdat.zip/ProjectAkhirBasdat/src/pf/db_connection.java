
package pf;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class db_connection {
    
    static Connection conn = null;
    
    public db_connection(){
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url = "jdbc:sqlserver://LAPTOP-D0S2PLFG\\MSSQLSERVER01:1433;Database=p_f";
            String user = "billy123";
            String password = "awefghj123";
            db_connection.conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connected Successfully");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(db_connection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ResultSet TableData(String table){
        ResultSet rs = null;
        try {
            Statement st = db_connection.conn.createStatement();
            String query = "select * from " + table;
            rs = st.executeQuery(query);
        } catch (SQLException ex) {
            Logger.getLogger(db_connection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }

    void Close() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
  void  noErr(){
        
    }
}
