package pf;

import java.sql.*;
import java.awt.Dimension;
import java.awt.Toolkit;
import static java.lang.Integer.parseInt;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class DetailedCart extends javax.swing.JFrame {

    static int niu;
    static String timeWanted;

    public DetailedCart() {
        initComponents();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width / 2 - getWidth() / 2, size.height / 2 - getHeight() / 2);
        dontDelete();
        jLT.setText(showRName(Restaurant_detail.idr));
        showTableData(Login.user, Restaurant_detail.idr);
        jLTotHarga.setText((getTotalCost()).toString());
        jLabel5.setVisible(false);
    }

    private String showRName(int id_penjual) {
        String name = "";
        try {
            String q = "select nama_toko from penjual where id_penjual=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, id_penjual);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                name = rs.getString("nama_toko");
            }

        } catch (SQLException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
        return name;
    }

    private Integer getTotalCost() {
        int res = -1;
        DefaultTableModel tbl = (DefaultTableModel) jTableIsiKeranjang.getModel();
        for (int i = 0; i < tbl.getRowCount(); i++) {
            Object c = jTableIsiKeranjang.getValueAt(i, 2);
            res += parseInt(c.toString());
        }
        return res + 1;
    }

    private void showTableData(String no_hp, int id_penjual) {
        try {
            DefaultTableModel tbl = (DefaultTableModel) jTableIsiKeranjang.getModel();
            String q = "select nama_makanan, kuantitas, harga from buatTabelRM where no_hp=? and id_penjual=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setString(1, no_hp);
            st.setInt(2, id_penjual);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Object nama_makanan = rs.getString(1);
                Object kuantitas = rs.getInt(2);
                Object harga = rs.getString(3);
                int hk = parseInt(kuantitas.toString()) * parseInt(harga.toString());
                Object[] data = {nama_makanan, kuantitas, hk};
                tbl.addRow(data);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DetailedCart.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void dontDelete() {
        FPage.dc.noErr();
    }

    private void createOrder(int id_pegawai, String no_hp, String tanggal_pesanan, String mp, String alamat, int sp) {
        try {
            String q = "insert into pesanan(id_pegawai_kurir, no_hp, tanggal_pesanan, metode_pembayaran, alamat_pengiriman, status_pesanan)"
                    + "values(?,?,?,?,?,?)";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, id_pegawai);
            st.setString(2, no_hp);
            st.setString(3, tanggal_pesanan);
            st.setString(4, mp);
            st.setString(5, alamat);
            st.setInt(6, sp);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DetailedCart.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private int getRandomDriver() {
        int id = -1;
        try {
            String q = "select top 1 id_pegawai from kurir order by newid()";
            Statement st = db_connection.conn.createStatement();
            ResultSet r = st.executeQuery(q);
            while (r.next()) {
                id = r.getInt("id_pegawai");
            }
        } catch (SQLException ex) {
            Logger.getLogger(DetailedCart.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id;
    }
    
       private String getCurrentTime(){
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
        LocalDateTime now = LocalDateTime.now();  
        return dtf.format(now);
    }
    
    private int getIdMenu(int id_penjual, String nama_makanan, int harga){
        int id = -1;
        try {
            String q = "select id_makanan from menu where id_penjual=? and harga=? and nama_makanan=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, id_penjual);
            st.setInt(2, harga);
            st.setString(3, nama_makanan);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                id = rs.getInt("id_makanan");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Restaurant_detail.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id;
    }
    
    private int getNewOrder(){
        int no = -1;
        try {
            ResultSet res = FPage.dc.TableData("cekMenuDiListMenu");
            while(res.next()){
                no = res.getInt("no_pesanan");
            }
        } catch (SQLException ex) {
            Logger.getLogger(DetailedCart.class.getName()).log(Level.SEVERE, null, ex);
        }
        return no;
    }
    
    private void addListMenu(int no_pesanan, int id_menu, int kuantitas){
        try {
            String q = "insert into list_menu values(?,?,?)";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, no_pesanan);
            st.setInt(2, id_menu);
            st.setInt(3, kuantitas);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DetailedCart.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void deleteMenambahkan(int no_keranjang){
        try {
            String q = "delete from menambahkan where no_keranjang=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, no_keranjang);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void deleteCart(int no_keranjang){
        try {
            String q = "delete from keranjang where no_keranjang=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setInt(1, no_keranjang);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private int getSaldoOVO(String no_hp){
        int saldo = 0;
        try {
            String q = "select saldo_ovo from pembeli where no_hp=?";
            PreparedStatement st = db_connection.conn.prepareStatement(q);
            st.setString(1, no_hp);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                saldo = rs.getInt("saldo_ovo");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
        }
        return saldo;
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableIsiKeranjang = new javax.swing.JTable();
        jPanel8 = new javax.swing.JPanel();
        jLogOut = new javax.swing.JButton();
        jLabelDriversR = new javax.swing.JLabel();
        jLabelDriversR3 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabelPF7 = new javax.swing.JLabel();
        jLabelRiwayat = new javax.swing.JLabel();
        jLabelRiwayat1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLT = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jBEditPesanan = new javax.swing.JButton();
        jBPesan = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jTFAlamat = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jCBMP = new javax.swing.JComboBox<>();
        jLTotHarga = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLSaldo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 204, 255));
        jPanel1.setForeground(new java.awt.Color(255, 204, 255));

        jTableIsiKeranjang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nama Makanan", "Kuantitas", "Harga"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableIsiKeranjang.setToolTipText("");
        jScrollPane1.setViewportView(jTableIsiKeranjang);

        jPanel8.setBackground(new java.awt.Color(255, 153, 255));
        jPanel8.setForeground(new java.awt.Color(51, 51, 51));

        jLogOut.setBackground(new java.awt.Color(255, 0, 153));
        jLogOut.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLogOut.setForeground(new java.awt.Color(255, 255, 255));
        jLogOut.setText("Log Out");
        jLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jLogOutActionPerformed(evt);
            }
        });

        jLabelDriversR.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelDriversR.setForeground(new java.awt.Color(51, 51, 51));
        jLabelDriversR.setText("RIWAYAT");
        jLabelDriversR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelDriversRMouseClicked(evt);
            }
        });

        jLabelDriversR3.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelDriversR3.setForeground(new java.awt.Color(51, 51, 51));
        jLabelDriversR3.setText("PENGATURAN");
        jLabelDriversR3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelDriversR3MouseClicked(evt);
            }
        });

        jPanel9.setBackground(new java.awt.Color(255, 51, 255));

        jLabelPF7.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        jLabelPF7.setForeground(new java.awt.Color(255, 255, 255));
        jLabelPF7.setText("PATRICK FOODIES");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelPF7, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelPF7)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jLabelRiwayat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/download-removebg-preview (1).png"))); // NOI18N
        jLabelRiwayat.setText("jLabel5");

        jLabelRiwayat1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/12345__1_-removebg-preview.png"))); // NOI18N
        jLabelRiwayat1.setText("jLabel5");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabelRiwayat, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelDriversR)
                            .addComponent(jLabelDriversR3)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addComponent(jLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGap(32, 32, 32)
                    .addComponent(jLabelRiwayat1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(152, Short.MAX_VALUE)))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelDriversR3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelRiwayat, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(73, 73, 73)
                .addComponent(jLabelDriversR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(64, 64, 64)
                .addComponent(jLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53))
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                    .addContainerGap(214, Short.MAX_VALUE)
                    .addComponent(jLabelRiwayat1, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(123, 123, 123)))
        );

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Cart");

        jLT.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLT.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLT, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));
        jPanel3.setForeground(new java.awt.Color(255, 153, 255));

        jPanel4.setBackground(new java.awt.Color(255, 51, 255));

        jBEditPesanan.setBackground(new java.awt.Color(255, 153, 153));
        jBEditPesanan.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBEditPesanan.setForeground(new java.awt.Color(255, 255, 255));
        jBEditPesanan.setText("Edit Pesanan");
        jBEditPesanan.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jBEditPesanan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBEditPesananActionPerformed(evt);
            }
        });

        jBPesan.setBackground(new java.awt.Color(102, 255, 102));
        jBPesan.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBPesan.setForeground(new java.awt.Color(255, 255, 255));
        jBPesan.setText("Pesan");
        jBPesan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBPesanActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jBEditPesanan, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jBPesan, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(jBPesan, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jBEditPesanan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Alamat Pengiriman :");

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Metode Pembayaran :");

        jCBMP.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jCBMP.setForeground(new java.awt.Color(255, 255, 255));
        jCBMP.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tunai", "OVO" }));
        jCBMP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCBMPActionPerformed(evt);
            }
        });

        jLTotHarga.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLTotHarga.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Total :");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Saldo :");

        jLSaldo.setBackground(new java.awt.Color(255, 255, 255));
        jLSaldo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLSaldo.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jCBMP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLTotHarga, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLSaldo, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTFAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jTFAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jCBMP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLTotHarga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLSaldo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBEditPesananActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBEditPesananActionPerformed
        // TODO add your handling code here:
        Home.forDetailR = Restaurant_detail.idr;
        new Restaurant_detail().setVisible(true);
        dispose();
    }//GEN-LAST:event_jBEditPesananActionPerformed

    private void jBPesanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBPesanActionPerformed
        // TODO add your handling code here:
        int id_pegawai = getRandomDriver();
        String no_hp = Login.user;
        String tanggal = getCurrentTime();
        String mp = jCBMP.getSelectedItem().toString();
        String alamat = jTFAlamat.getText();
        int sp = 1;
        if (!alamat.equals("")) {
            if (mp.equals("OVO") && getSaldoOVO(Login.user) >= parseInt(jLTotHarga.getText()) || mp.equals("Tunai")) {
                createOrder(id_pegawai, no_hp, tanggal, mp, alamat, sp);
                niu = getNewOrder();
                int no_keranjang = Restaurant_detail.isCartExist(Restaurant_detail.idr, Login.user);
                for (int i = 0; i < jTableIsiKeranjang.getRowCount(); i++) {
                    Object nama_makanan = jTableIsiKeranjang.getValueAt(i, 0);
                    Object kuantitas = jTableIsiKeranjang.getValueAt(i, 1);
                    Object harga = jTableIsiKeranjang.getValueAt(i, 2);
                    Object hargaFix = parseInt(harga.toString()) / parseInt(kuantitas.toString());
                    int id_menu = getIdMenu(Restaurant_detail.idr, nama_makanan.toString(), parseInt(hargaFix.toString()));
                    System.out.println("ID MENU " + id_menu);
                    addListMenu(niu, id_menu, parseInt(kuantitas.toString()));
                }
                deleteMenambahkan(no_keranjang);
                deleteCart(no_keranjang);
                jTFAlamat.setText("");
                JOptionPane.showMessageDialog(this, "Pesanan sedang diproses.");
                new Otw().setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Saldo OVO tidak cukup.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Harap isi alamat tujuan.");
        }
    }//GEN-LAST:event_jBPesanActionPerformed

    private void jCBMPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCBMPActionPerformed
         if(jCBMP.getSelectedItem().equals("OVO")){
            jLSaldo.setVisible(true);
            jLabel5.setVisible(true);
            jLSaldo.setText(String.valueOf(getSaldoOVO(Login.user)));
        }
        else{
            jLSaldo.setVisible(false);
            jLabel5.setVisible(false);
        }
    }//GEN-LAST:event_jCBMPActionPerformed

    private void jLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jLogOutActionPerformed
        Login.user = "";
        new Login().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLogOutActionPerformed

    private void jLabelDriversRMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelDriversRMouseClicked
        new History().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelDriversRMouseClicked

    private void jLabelDriversR3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelDriversR3MouseClicked
        new Setting().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelDriversR3MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DetailedCart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DetailedCart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DetailedCart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DetailedCart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DetailedCart().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBEditPesanan;
    private javax.swing.JButton jBPesan;
    private javax.swing.JComboBox<String> jCBMP;
    private javax.swing.JLabel jLSaldo;
    private javax.swing.JLabel jLT;
    private javax.swing.JLabel jLTotHarga;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabelDriversR;
    private javax.swing.JLabel jLabelDriversR3;
    private javax.swing.JLabel jLabelPF7;
    private javax.swing.JLabel jLabelRiwayat;
    private javax.swing.JLabel jLabelRiwayat1;
    private javax.swing.JButton jLogOut;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTFAlamat;
    private javax.swing.JTable jTableIsiKeranjang;
    // End of variables declaration//GEN-END:variables
}
