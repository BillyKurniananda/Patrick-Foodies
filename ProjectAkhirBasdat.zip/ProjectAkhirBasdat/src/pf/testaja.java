
package pf;

import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;   

public class testaja {
    public static void main(String[] args) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");  
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime next = LocalDateTime.now();
        System.out.println(dtf.format(now)); 
        System.out.println(dtf.format(now.plusSeconds(15)));
        System.out.println(dtf.format(next)); 
        System.out.println("begin tran\n"
                        + "update pesanan set status_pesanan=2 where no_pesanan=?\n"
                        + "commit tran");
    }
    
}