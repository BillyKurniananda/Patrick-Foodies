/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pf;

import java.sql.*;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Drivers extends javax.swing.JFrame {

    String status = "";
    
    public Drivers() {
        initComponents();
        Toolkit toolkit = getToolkit();
        Dimension size = toolkit.getScreenSize();
        setLocation(size.width/2 - getWidth()/2, size.height/2 - getHeight()/2);
        showTableData();
        jButtonSave.setEnabled(false);
        jButtonCancel.setEnabled(false);
    }
    
    private void saveAdd(String no_hp, String nama, String jenis_kelamin, String pk){
         try {
            String queryAdd = "insert into kurir(no_hp, nama, jenis_kelamin, plat_kendaraan) values(?,?,?,?)";
            PreparedStatement st = db_connection.conn.prepareStatement(queryAdd);
            st.setString(1, no_hp);
            st.setString(2, nama);
            st.setString(3, jenis_kelamin);
            st.setString(4, pk);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Drivers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void deleteRecord(int id){
        try {
            String queryDelete = "delete from kurir where id_pegawai=?";
            PreparedStatement st = db_connection.conn.prepareStatement(queryDelete);
            st.setInt(1, id);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Drivers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void cancel(){
        status = "";
        jButtonAdd.setEnabled(true);
        jButtonDelete.setEnabled(true);
        jButtonEdit.setEnabled(true);
        jButtonSave.setEnabled(false);
        jButtonCancel.setEnabled(false);
        jTFNoHp.setText("");
        jTFNama.setText("");
        jTFPlatKendaraan.setText("");
        buttonGroupJK.clearSelection();
        clearTable();
        showTableData();   
    }
    
    private void saveEdit(int id, String no_hp, String nama, String jk, String pk){
        try {
            String queryEdit = "update kurir set no_hp=?, nama=?, jenis_kelamin=?, plat_kendaraan=? where id_pegawai=?";
            PreparedStatement st = db_connection.conn.prepareStatement(queryEdit);
            st.setString(1, no_hp);
            st.setString(2, nama);
            st.setString(3, jk);
            st.setString(4, pk);
            st.setInt(5, id);
            st.execute();
        } catch (SQLException ex) {
            Logger.getLogger(Drivers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void showTableData(){
        try {
            ResultSet x = FPage.dc.TableData("kurir");
            while(x.next()){
                Object id_pegawai = x.getInt(1);
                Object no_hp = x.getString(2);
                Object nama = x.getString(3);
                Object j_k = x.getString(4);
                Object pk = x.getString(5);
                Object[] data = {id_pegawai, no_hp, nama, j_k, pk};
                
                DefaultTableModel tblModelDrivers = (DefaultTableModel)jTableDrivers.getModel();
                tblModelDrivers.addRow(data);    
            }
        } catch (SQLException ex) {
            Logger.getLogger(Drivers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void search(Object y){
        try {
            ResultSet x = FPage.dc.TableData("kurir");
            DefaultTableModel tblModelDrivers = (DefaultTableModel)jTableDrivers.getModel();
            while(x.next()){
                Object id_pegawai = x.getInt(1);
                Object no_hp = x.getString(2);
                Object nama = x.getString(3);
                Object j_k = x.getString(4);
                Object pk = x.getString(5);
                Object[] data = {id_pegawai, no_hp, nama, j_k, pk};
                if(id_pegawai.toString().equals(y)|| no_hp.toString().equalsIgnoreCase(y.toString())
                        || nama.toString().equalsIgnoreCase(y.toString()) || j_k.toString().equalsIgnoreCase(y.toString())
                        || pk.toString().equalsIgnoreCase(y.toString())){
                    tblModelDrivers.addRow(data);       
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(Drivers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void searchLike(String x){
        try {
            DefaultTableModel tblModelDrivers = (DefaultTableModel)jTableDrivers.getModel();
            PreparedStatement statement = db_connection.conn.prepareStatement(
                    "select * from kurir where nama like ?");
            String q = "%" + x + "%";
            statement.setString(1,q);
            ResultSet resultSet = statement.executeQuery();
            
            while(resultSet.next()){
                Object id_pegawai = resultSet.getInt(1);
                Object no_hp = resultSet.getString(2);
                Object nama = resultSet.getString(3);
                Object j_k = resultSet.getString(4);
                Object[] data = {id_pegawai, no_hp, nama, j_k};
                tblModelDrivers.addRow(data);  
            }
        } catch (SQLException ex) {
            Logger.getLogger(Drivers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void clearTable(){
        DefaultTableModel tblModelDrivers = (DefaultTableModel)jTableDrivers.getModel();
        int rowsCount = tblModelDrivers.getRowCount();
        for(int i = rowsCount-1; i>=0; i--){
            tblModelDrivers.removeRow(i);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroupJK = new javax.swing.ButtonGroup();
        jPanel4 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabelPF1 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabelDrivers1 = new javax.swing.JLabel();
        jLabelCustomers1 = new javax.swing.JLabel();
        jLabelOrders1 = new javax.swing.JLabel();
        jLabelSellers1 = new javax.swing.JLabel();
        jLabelImgDriver1 = new javax.swing.JLabel();
        jLabelImgOrders1 = new javax.swing.JLabel();
        jLabelImgCust2 = new javax.swing.JLabel();
        jLabelImgSeller1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableDrivers = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabelDriversR = new javax.swing.JLabel();
        jTFSearch = new javax.swing.JTextField();
        jButtonSearch = new javax.swing.JButton();
        jButtonX = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jButtonAdd = new javax.swing.JButton();
        jButtonEdit = new javax.swing.JButton();
        jButtonDelete = new javax.swing.JButton();
        jButtonSave = new javax.swing.JButton();
        jButtonCancel = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTFNoHp = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTFNama = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jRBPria = new javax.swing.JRadioButton();
        jRBWanita = new javax.swing.JRadioButton();
        jLabel4 = new javax.swing.JLabel();
        jTFPlatKendaraan = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(new java.awt.Dimension(790, 520));

        jPanel4.setBackground(new java.awt.Color(51, 51, 51));

        jPanel2.setBackground(new java.awt.Color(255, 51, 255));

        jLabelPF1.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        jLabelPF1.setForeground(new java.awt.Color(255, 255, 255));
        jLabelPF1.setText("PATRICK FOODIES");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelPF1, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelPF1)
                .addGap(30, 30, 30))
        );

        jPanel8.setBackground(new java.awt.Color(51, 51, 51));

        jLabelDrivers1.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelDrivers1.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDrivers1.setText("Drivers");
        jLabelDrivers1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelDriversMouseClicked(evt);
            }
        });

        jLabelCustomers1.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelCustomers1.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCustomers1.setText("Customers");
        jLabelCustomers1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelCustomersMouseClicked(evt);
            }
        });

        jLabelOrders1.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelOrders1.setForeground(new java.awt.Color(255, 255, 255));
        jLabelOrders1.setText("Orders");
        jLabelOrders1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelOrdersMouseClicked(evt);
            }
        });

        jLabelSellers1.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelSellers1.setForeground(new java.awt.Color(255, 255, 255));
        jLabelSellers1.setText("Sellers");
        jLabelSellers1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelSellersMouseClicked(evt);
            }
        });

        jLabelImgDriver1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-scooter-60.png"))); // NOI18N
        jLabelImgDriver1.setText("jLabel1");

        jLabelImgOrders1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-order-64.png"))); // NOI18N

        jLabelImgCust2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-customer-64.png"))); // NOI18N
        jLabelImgCust2.setText("jLabel1");

        jLabelImgSeller1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-store-64.png"))); // NOI18N

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setText("Kembali ke Beranda");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabelImgOrders1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabelImgCust2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabelImgDriver1, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))
                            .addComponent(jLabelImgSeller1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelDrivers1)
                            .addComponent(jLabelOrders1)
                            .addComponent(jLabelCustomers1)
                            .addComponent(jLabelSellers1)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelImgDriver1)
                    .addComponent(jLabelDrivers1))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(jLabelCustomers1))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabelImgCust2)))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jLabelImgOrders1))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(jLabelOrders1)))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(jLabelSellers1))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jLabelImgSeller1)))
                .addGap(38, 38, 38)
                .addComponent(jButton2)
                .addContainerGap(46, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(255, 204, 255));

        jTableDrivers.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTableDrivers.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID_Pegawai", "No_HP", "Nama", "Jenis Kelamin", "Plat Kendaraan"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableDrivers.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTableDrivers.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTableDrivers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableDriversMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableDrivers);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        jLabelDriversR.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabelDriversR.setForeground(new java.awt.Color(255, 255, 255));
        jLabelDriversR.setText("DRIVERS");

        jTFSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFSearchActionPerformed(evt);
            }
        });

        jButtonSearch.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pf/img/icons8-search-24.png"))); // NOI18N
        jButtonSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSearchActionPerformed(evt);
            }
        });

        jButtonX.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonX.setText("X");
        jButtonX.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonXActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelDriversR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTFSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButtonX, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButtonSearch, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabelDriversR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTFSearch)
                    .addComponent(jButtonX, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));

        jButtonAdd.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonAdd.setText("Add");
        jButtonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddActionPerformed(evt);
            }
        });

        jButtonEdit.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonEdit.setText("Edit");
        jButtonEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditActionPerformed(evt);
            }
        });

        jButtonDelete.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonDelete.setText("Delete");
        jButtonDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDeleteActionPerformed(evt);
            }
        });

        jButtonSave.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonSave.setText("Save");
        jButtonSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSaveActionPerformed(evt);
            }
        });

        jButtonCancel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonCancel.setText("Cancel");
        jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jButtonAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButtonEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButtonDelete)
                .addGap(18, 18, 18)
                .addComponent(jButtonSave)
                .addGap(18, 18, 18)
                .addComponent(jButtonCancel)
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE, false)
                    .addComponent(jButtonEdit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonDelete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonSave, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonCancel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel7.setBackground(new java.awt.Color(51, 51, 51));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText(" No.Hp ");

        jTFNoHp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFNoHpActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nama");

        jTFNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFNamaActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Jenis Kelamin");

        jRBPria.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroupJK.add(jRBPria);
        jRBPria.setForeground(new java.awt.Color(255, 255, 255));
        jRBPria.setText("M");
        jRBPria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRBPriaActionPerformed(evt);
            }
        });

        jRBWanita.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroupJK.add(jRBWanita);
        jRBWanita.setForeground(new java.awt.Color(255, 255, 255));
        jRBWanita.setText("F");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Plat Kendaraan");

        jTFPlatKendaraan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTFPlatKendaraanActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTFNama, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTFNoHp, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel7Layout.createSequentialGroup()
                            .addComponent(jRBPria, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jRBWanita, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addContainerGap())
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addGap(113, 113, 113)))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jTFPlatKendaraan, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(90, 90, 90))))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFNoHp)
                    .addComponent(jRBPria)
                    .addComponent(jRBWanita))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTFNama)
                    .addComponent(jTFPlatKendaraan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(56, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTFSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFSearchActionPerformed
        // TODO add your handling code here:
        if(jTFSearch.getText().equals("")){
            clearTable();
            showTableData();
        }
    }//GEN-LAST:event_jTFSearchActionPerformed

    private void jButtonSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSearchActionPerformed
        // TODO add your handling code here:
        if(!jTFSearch.getText().equals("")){
            DefaultTableModel tblModelDrivers = (DefaultTableModel)jTableDrivers.getModel();
            clearTable();
            Object x = jTFSearch.getText();
            search(x);
            if(tblModelDrivers.getRowCount()==0){
                searchLike(x.toString());
            }
        }
    }//GEN-LAST:event_jButtonSearchActionPerformed

    private void jTFNoHpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFNoHpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFNoHpActionPerformed

    private void jTFNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFNamaActionPerformed

    private void jRBPriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRBPriaActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jRBPriaActionPerformed

    private void jButtonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddActionPerformed
        // TODO add your handling code here:
        jButtonAdd.setEnabled(false);
        jButtonDelete.setEnabled(false);
        jButtonEdit.setEnabled(false);
        jButtonSave.setEnabled(true);
        jButtonCancel.setEnabled(true);
        jTFNoHp.setText("");
        jTFNama.setText("");
        buttonGroupJK.clearSelection();
        status = "add";
    }//GEN-LAST:event_jButtonAddActionPerformed

    private void jButtonDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDeleteActionPerformed
        if(jTableDrivers.getSelectionModel().isSelectionEmpty()){
            JOptionPane.showMessageDialog(this,"Select a record!");
        }
        else{
            int response = JOptionPane.showConfirmDialog(this, "Do you want to delete this record?", "Confirm",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if(response==JOptionPane.YES_OPTION){
                DefaultTableModel tbl = (DefaultTableModel)jTableDrivers.getModel();
                int id = (int)tbl.getValueAt(jTableDrivers.getSelectedRow(), 0);
                deleteRecord(id);
                cancel();
            }
        }
    }//GEN-LAST:event_jButtonDeleteActionPerformed

    private void jButtonSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSaveActionPerformed
        
        DefaultTableModel tbl = (DefaultTableModel)jTableDrivers.getModel();
        String no_hp = jTFNoHp.getText();
        String nama = jTFNama.getText();
        String pk = jTFPlatKendaraan.getText();
        String jk = "";
        if(jRBPria.isSelected()){
            jk = "M";
        }
        else if(jRBWanita.isSelected()){
            jk = "F";
        }
        
        if(!no_hp.equals("") && !nama.equals("") && !jk.equals("")){
            
            if(status.equals("add")){
                saveAdd(no_hp, nama, jk, pk);
            }
            else if(status.equals("edit")){
                int id = (int)tbl.getValueAt(jTableDrivers.getSelectedRow(), 0);
                saveEdit(id, no_hp, nama, jk, pk);
            }        
            
            cancel(); 
        }
        else{
            JOptionPane.showMessageDialog(this, "Input all the data!");
            cancel();
        }
            
    }//GEN-LAST:event_jButtonSaveActionPerformed

    private void jButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelActionPerformed
        // TODO add your handling code here:
        cancel();
    }//GEN-LAST:event_jButtonCancelActionPerformed

    private void jTableDriversMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableDriversMouseClicked
        
        jTableDrivers.setRowSelectionAllowed(true);
        DefaultTableModel tbl = (DefaultTableModel)jTableDrivers.getModel();
        String no_hp = tbl.getValueAt(jTableDrivers.getSelectedRow(), 1).toString();
        String nama = tbl.getValueAt(jTableDrivers.getSelectedRow(), 2).toString();
        String jk = tbl.getValueAt(jTableDrivers.getSelectedRow(), 3).toString();
        String pk = tbl.getValueAt(jTableDrivers.getSelectedRow(), 4).toString();
        
        jTFNama.setText(nama);
        jTFNoHp.setText(no_hp);
        jTFPlatKendaraan.setText(pk);
        if(jk.equalsIgnoreCase("M")){
            jRBPria.setSelected(true);
        }
        else{
            jRBWanita.setSelected(true);
        }
    }//GEN-LAST:event_jTableDriversMouseClicked

    private void jButtonEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditActionPerformed
        // TODO add your handling code here:
        if(jTableDrivers.getSelectionModel().isSelectionEmpty()){
            JOptionPane.showMessageDialog(this,"Select a record!");
        }
        else{
            jButtonAdd.setEnabled(false);
            jButtonDelete.setEnabled(false);
            jButtonEdit.setEnabled(false);
            jButtonSave.setEnabled(true);
            jButtonCancel.setEnabled(true);
            status = "edit";
        }
    }//GEN-LAST:event_jButtonEditActionPerformed

    private void jButtonXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonXActionPerformed
        // TODO add your handling code here:
        jTFSearch.setText("");
        jTFNoHp.setText("");
        jTFNama.setText("");
        jTFPlatKendaraan.setText("");
        buttonGroupJK.clearSelection();
        clearTable();
        showTableData();
    }//GEN-LAST:event_jButtonXActionPerformed

    private void jTFPlatKendaraanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFPlatKendaraanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTFPlatKendaraanActionPerformed

    private void jLabelSellersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelSellersMouseClicked
        new Sellers().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelSellersMouseClicked

    private void jLabelOrdersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelOrdersMouseClicked
        // TODO add your handling code here:
        new Orders().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelOrdersMouseClicked

    private void jLabelCustomersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelCustomersMouseClicked
        // TODO add your handling code here:
        new Customers().setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabelCustomersMouseClicked

    private void jLabelDriversMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelDriversMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabelDriversMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        new firstPage().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Drivers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Drivers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Drivers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Drivers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Drivers().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroupJK;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButtonAdd;
    private javax.swing.JButton jButtonCancel;
    private javax.swing.JButton jButtonDelete;
    private javax.swing.JButton jButtonEdit;
    private javax.swing.JButton jButtonSave;
    private javax.swing.JButton jButtonSearch;
    private javax.swing.JButton jButtonX;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabelCustomers1;
    private javax.swing.JLabel jLabelDrivers1;
    private javax.swing.JLabel jLabelDriversR;
    private javax.swing.JLabel jLabelImgCust2;
    private javax.swing.JLabel jLabelImgDriver1;
    private javax.swing.JLabel jLabelImgOrders1;
    private javax.swing.JLabel jLabelImgSeller1;
    private javax.swing.JLabel jLabelOrders1;
    private javax.swing.JLabel jLabelPF1;
    private javax.swing.JLabel jLabelSellers1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JRadioButton jRBPria;
    private javax.swing.JRadioButton jRBWanita;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTFNama;
    private javax.swing.JTextField jTFNoHp;
    private javax.swing.JTextField jTFPlatKendaraan;
    private javax.swing.JTextField jTFSearch;
    private javax.swing.JTable jTableDrivers;
    // End of variables declaration//GEN-END:variables
}
